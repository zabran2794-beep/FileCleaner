# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep public class com.filecleaner.pro.FileCleanerInterface {
    @android.webkit.JavascriptInterface <methods>;
}
