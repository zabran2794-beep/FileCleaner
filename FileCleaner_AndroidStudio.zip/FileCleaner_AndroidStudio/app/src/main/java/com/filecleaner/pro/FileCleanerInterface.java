package com.filecleaner.pro;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileCleanerInterface {

    private Context context;
    private Activity activity;

    public FileCleanerInterface(Activity activity) {
        this.activity = activity;
        this.context = activity.getApplicationContext();
    }

    @JavascriptInterface
    public String getStorageInfo() {
        try {
            StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long blockSize = stat.getBlockSizeLong();
            long totalBlocks = stat.getBlockCountLong();
            long availableBlocks = stat.getAvailableBlocksLong();
            long total = totalBlocks * blockSize;
            long available = availableBlocks * blockSize;
            long used = total - available;

            JSONObject info = new JSONObject();
            info.put("total", total);
            info.put("used", used);
            info.put("free", available);
            info.put("totalGB", String.format("%.1f", total / (1024.0 * 1024.0 * 1024.0)));
            info.put("usedGB", String.format("%.1f", used / (1024.0 * 1024.0 * 1024.0)));
            info.put("freeGB", String.format("%.1f", available / (1024.0 * 1024.0 * 1024.0)));
            info.put("usedPercent", (int)((used * 100) / total));
            return info.toString();
        } catch (Exception e) {
            return "{\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    @JavascriptInterface
    public void showToast(String message) {
        activity.runOnUiThread(() ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        );
    }

    @JavascriptInterface
    public String getAppVersion() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.0";
        }
    }

    @JavascriptInterface
    public boolean deleteFile(String path) {
        try {
            File f = new File(path);
            if (f.exists()) {
                return deleteRecursive(f);
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) {
            for (File child : f.listFiles()) {
                deleteRecursive(child);
            }
        }
        return f.delete();
    }

    @JavascriptInterface
    public String scanCacheFiles() {
        JSONArray arr = new JSONArray();
        try {
            // App internal cache
            File cacheDir = context.getCacheDir();
            if (cacheDir.exists()) {
                JSONObject obj = new JSONObject();
                obj.put("name", "App Cache");
                obj.put("path", cacheDir.getAbsolutePath());
                obj.put("size", getDirSize(cacheDir));
                obj.put("sizeStr", formatSize(getDirSize(cacheDir)));
                obj.put("type", "cache");
                arr.put(obj);
            }
            // External cache
            File extCache = context.getExternalCacheDir();
            if (extCache != null && extCache.exists()) {
                JSONObject obj = new JSONObject();
                obj.put("name", "External Cache");
                obj.put("path", extCache.getAbsolutePath());
                obj.put("size", getDirSize(extCache));
                obj.put("sizeStr", formatSize(getDirSize(extCache)));
                obj.put("type", "cache");
                arr.put(obj);
            }
        } catch (Exception e) {
            // skip
        }
        return arr.toString();
    }

    private long getDirSize(File dir) {
        long size = 0;
        if (dir == null || !dir.exists()) return 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;
        for (File f : files) {
            if (f.isDirectory()) size += getDirSize(f);
            else size += f.length();
        }
        return size;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
